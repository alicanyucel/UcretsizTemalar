=====================================
!!! THANK YOU FOR PURCHASING FUSE !!!
=====================================

FILES:
fuse-demo-v17.2.0.zip   : Fuse Demo Project
fuse-starter-v17.2.0.zip: Fuse Starter Project

ONLINE DOCUMENTATION:
http://angular-material.fusetheme.com/docs/guides/getting-started/introduction

SUPPORT:
For your support requests please visit http://withinpixels.ticksy.com
Your requests will be queued and can take up to 48 hours in working days before answered.
